Core1 PCB
Bottomside layers are mirrored